package com.affordmed.problem2.model




data class Response(val keyword: String, val status: String, val prefix: String)