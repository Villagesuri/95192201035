package com.affordmed.demo.model

import java.util.*




data class Response(val numbers: SortedSet<Int>)