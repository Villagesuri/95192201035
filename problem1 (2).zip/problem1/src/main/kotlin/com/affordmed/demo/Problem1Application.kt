package com.affordmed.demo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Problem1Application

fun main(args: Array<String>) {
    runApplication<Problem1Application>(*args)
}