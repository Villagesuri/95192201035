import React, { useState } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

export default function NumbersFetcher() {
  const [urls, setUrls] = useState(['']);
  const [numbers, setNumbers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleUrlChange = (index, value) => {
    const newUrls = [...urls];
    newUrls[index] = value;
    setUrls(newUrls);
  };

  const addUrlField = () => setUrls([...urls, '']);

  const fetchNumbers = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = urls.filter(Boolean).map(u => `url=${encodeURIComponent(u)}`).join('&');
      const res = await axios.get(`/numbers?${params}`);
      setNumbers(res.data.numbers || []);
    } catch (err) {
      setError('Failed to fetch numbers.');
    }
    setLoading(false);
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Fetch Unique Numbers</h1>

      {urls.map((url, idx) => (
        <Input
          key={idx}
          className="mb-2"
          placeholder={`Enter URL #${idx + 1}`}
          value={url}
          onChange={e => handleUrlChange(idx, e.target.value)}
        />
      ))}

      <Button className="mb-4" onClick={addUrlField}>
        + Add URL
      </Button>
      <Button onClick={fetchNumbers} disabled={loading}>
        {loading ? 'Loading...' : 'Fetch Numbers'}
      </Button>

      {error && <p className="text-red-500 mt-2">{error}</p>}

      <Card className="mt-4">
        <CardContent>
          <h2 className="font-semibold mb-2">Unique Numbers:</h2>
          <p>{numbers.join(', ') || 'None'}</p>
        </CardContent>
      </Card>
    </div>
  );
}
