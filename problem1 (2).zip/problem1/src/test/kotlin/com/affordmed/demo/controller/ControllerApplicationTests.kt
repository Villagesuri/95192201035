package com.affordmed.demo.controller

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ControllerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
